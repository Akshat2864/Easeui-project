import Layout from "@/components/Layout/Layout";
import ComponentDemo from "../ComponentsDemo";
import PropsTable from "@/components/Personal/PropsTable";

const LayoutPage = () => {
  const layoutCode = `
import Layout from "@/components/Layout/Layout";

<Layout
  header={<div>Header</div>}
  sidebar={<div>Sidebar</div>}
  footer={<div>Footer</div>}
>
  <h1>Main Content</h1>
</Layout>
`;

  const propsData = [
    {
      prop: "header",
      type: "ReactNode",
      default: "undefined",
      description: "Content displayed in the header.",
    },
    {
      prop: "sidebar",
      type: "ReactNode",
      default: "undefined",
      description: "Content displayed in the sidebar.",
    },
    {
      prop: "children",
      type: "ReactNode",
      default: "-",
      description: "Main content of the layout.",
    },
    {
      prop: "footer",
      type: "ReactNode",
      default: "undefined",
      description: "Content displayed in the footer.",
    },
  ];

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-12">
      <header className="space-y-2">
        <h1 className="text-4xl font-bold">
          Layout
        </h1>

        <p className="text-lg text-gray-600 dark:text-gray-400">
          Provides a flexible page structure with header, sidebar, content,
          and footer sections.
        </p>
      </header>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">
          Usage
        </h2>

        <ComponentDemo code={layoutCode}>
          <div className="w-full h-80 border border-gray-300 dark:border-zinc-700 rounded-lg overflow-hidden">
            <Layout
              header={
                <div className="p-3 bg-gray-100 dark:bg-zinc-800 border-b">
                  Header
                </div>
              }
              sidebar={
                <div className="p-3 h-full bg-gray-50 dark:bg-zinc-900">
                  Sidebar
                </div>
              }
              footer={
                <div className="p-3 bg-gray-100 dark:bg-zinc-800 border-t">
                  Footer
                </div>
              }
            >
              <div>
                Main Content
              </div>
            </Layout>
          </div>
        </ComponentDemo>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">
          API Reference
        </h2>

        <PropsTable data={propsData} />
      </section>
    </div>
  );
};

export default LayoutPage;