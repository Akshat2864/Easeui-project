import Carousel from "@/components/Carousel/Carousel";
import ComponentDemo from "../ComponentsDemo";
import PropsTable from "@/components/Personal/PropsTable";

const CarouselPage = () => {
  const carouselCode = `
import Carousel from "@/components/Carousel/Carousel";

<Carousel autoPlay interval={3000}>
  <div>Slide 1</div>
  <div>Slide 2</div>
  <div>Slide 3</div>
</Carousel>
`;

  const propsData = [
    {
      prop: "autoPlay",
      type: "boolean",
      default: "false",
      description: "Automatically moves to the next slide.",
    },
    {
      prop: "interval",
      type: "number",
      default: "3000",
      description: "Time between automatic slide changes in milliseconds.",
    },
    {
      prop: "loop",
      type: "boolean",
      default: "true",
      description: "Determines whether the carousel loops after the last slide.",
    },
  ];

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-12">
      <header className="space-y-2">
        <h1 className="text-4xl font-bold">
          Carousel
        </h1>

        <p className="text-lg text-gray-600 dark:text-gray-400">
          Displays a collection of content that can be navigated through slides.
        </p>
      </header>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">
          Usage
        </h2>

        <ComponentDemo code={carouselCode}>
          <div className="w-full max-w-xl">
            <Carousel autoPlay interval={3000}>
              {[
                <div className="h-60 bg-blue-500 flex items-center justify-center text-white text-2xl">
                  Slide 1
                </div>,

                <div className="h-60 bg-purple-500 flex items-center justify-center text-white text-2xl">
                  Slide 2
                </div>,

                <div className="h-60 bg-green-500 flex items-center justify-center text-white text-2xl">
                  Slide 3
                </div>,
              ]}
            </Carousel>
          </div>
        </ComponentDemo>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">
          API Reference
        </h2>

        <PropsTable data={propsData} />
      </section>
    </div>
  );
};

export default CarouselPage;