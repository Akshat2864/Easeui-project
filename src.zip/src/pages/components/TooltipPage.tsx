import Tooltip from "@/components/Tooltip/Tooltip";
import ComponentDemo from "../ComponentsDemo";
import PropsTable from "@/components/Personal/PropsTable";

const TooltipPage = () => {
  const tooltipCode = `
import Tooltip from "@/components/Tooltip/Tooltip";

<Tooltip content="Hello!" position="top">
  <button>Hover me</button>
</Tooltip>
`;

  const propsData = [
    {
      prop: "content",
      type: "string",
      default: "-",
      description: "Content displayed inside the tooltip.",
    },
    {
      prop: "position",
      type: '"top" | "bottom" | "left" | "right"',
      default: '"top"',
      description: "Position of the tooltip relative to the element.",
    },
  ];

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-12">
      <header className="space-y-2">
        <h1 className="text-4xl font-bold">
          Tooltip
        </h1>

        <p className="text-lg text-gray-600 dark:text-gray-400">
          Displays additional information when the user hovers over an element.
        </p>
      </header>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">
          Usage
        </h2>

        <ComponentDemo code={tooltipCode}>
          <div className="py-12">
            <Tooltip content="This is a tooltip">
              <button className="rounded-md bg-blue-600 px-5 py-2 text-white">
                Hover me
              </button>
            </Tooltip>
          </div>
        </ComponentDemo>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">
          API Reference
        </h2>

        <PropsTable data={propsData} />
      </section>
    </div>
  );
};

export default TooltipPage;